$(".animate").hide().show(800);
$(".fade").hide().fadeIn(800,"swing");